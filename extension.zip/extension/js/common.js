const msgPattern = /443\{([0-9a-f]+)\}336/i;
const failedDecryption = "[[PS: message decryption failed]]";
const failedEncryption = "[[PS: message encryption failed]]";
const counterVal = 17;